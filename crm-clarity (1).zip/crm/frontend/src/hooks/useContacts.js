import { useState, useCallback } from "react";
import api from "../lib/api";
import toast from "react-hot-toast";

export function useContacts() {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchContacts = useCallback(async (search = "") => {
    setLoading(true);
    try {
      const params = search ? { search } : {};
      const { data } = await api.get("/contacts", { params });
      setContacts(data);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const createContact = async (payload) => {
    const { data } = await api.post("/contacts", payload);
    setContacts((prev) => [data, ...prev]);
    return data;
  };

  const updateContact = async (id, payload) => {
    const { data } = await api.put(`/contacts/${id}`, payload);
    setContacts((prev) => prev.map((c) => (c.id === id ? data : c)));
    return data;
  };

  const deleteContact = async (id) => {
    await api.delete(`/contacts/${id}`);
    setContacts((prev) => prev.filter((c) => c.id !== id));
  };

  return { contacts, loading, fetchContacts, createContact, updateContact, deleteContact };
}
