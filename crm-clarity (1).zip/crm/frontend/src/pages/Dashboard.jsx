import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../lib/api";
import {
  Users, TrendingUp, CheckCircle, Clock, ArrowRight, Plus
} from "lucide-react";

function StatCard({ label, value, icon: Icon, color, sub }) {
  return (
    <div className="card p-5 hover:shadow-card-hover transition-shadow duration-200">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-ink-muted uppercase tracking-wide">{label}</p>
          <p className="text-3xl font-display font-bold text-ink mt-1">{value ?? "—"}</p>
          {sub && <p className="text-xs text-ink-subtle mt-1">{sub}</p>}
        </div>
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [recentContacts, setRecentContacts] = useState([]);
  const [loading, setLoading] = useState(true);

  const firstName = user?.user_metadata?.full_name?.split(" ")[0] || "there";

  useEffect(() => {
    const load = async () => {
      try {
        const [statsRes, contactsRes] = await Promise.all([
          api.get("/stats"),
          api.get("/contacts", { params: { limit: 5 } }),
        ]);
        setStats(statsRes.data);
        setRecentContacts(contactsRes.data.slice(0, 5));
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const statusBadge = (status) => {
    const map = {
      lead: "badge-lead",
      contacted: "badge-contacted",
      proposal: "badge-proposal",
      closed: "badge-closed",
    };
    return <span className={map[status] || "badge-inactive"}>{status}</span>;
  };

  return (
    <div className="p-6 lg:p-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display font-bold text-2xl lg:text-3xl text-ink">
          Good morning, {firstName} 👋
        </h1>
        <p className="text-ink-muted mt-1 text-sm">Here's what's happening with your pipeline today.</p>
      </div>

      {/* Stats grid */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="card p-5 animate-pulse">
              <div className="h-4 bg-surface-200 rounded w-20 mb-3" />
              <div className="h-8 bg-surface-200 rounded w-12" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            label="Total Contacts"
            value={stats?.total}
            icon={Users}
            color="bg-brand-50 text-brand-600"
            sub="All time"
          />
          <StatCard
            label="Active Leads"
            value={stats?.leads}
            icon={TrendingUp}
            color="bg-blue-50 text-blue-600"
            sub="In pipeline"
          />
          <StatCard
            label="Proposals Sent"
            value={stats?.proposals}
            icon={Clock}
            color="bg-purple-50 text-purple-600"
            sub="Awaiting response"
          />
          <StatCard
            label="Closed Deals"
            value={stats?.closed}
            icon={CheckCircle}
            color="bg-green-50 text-green-600"
            sub="Successfully closed"
          />
        </div>
      )}

      {/* Recent contacts */}
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-surface-100">
          <h2 className="font-display font-semibold text-base text-ink">Recent Contacts</h2>
          <Link to="/contacts" className="flex items-center gap-1 text-xs font-medium text-brand-600 hover:text-brand-700">
            View all <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <div className="divide-y divide-surface-100">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-4 animate-pulse">
                <div className="w-9 h-9 bg-surface-200 rounded-xl" />
                <div className="flex-1">
                  <div className="h-4 bg-surface-200 rounded w-32 mb-2" />
                  <div className="h-3 bg-surface-100 rounded w-24" />
                </div>
              </div>
            ))}
          </div>
        ) : recentContacts.length === 0 ? (
          <div className="py-12 text-center">
            <div className="w-12 h-12 bg-surface-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
              <Users className="w-6 h-6 text-ink-subtle" />
            </div>
            <p className="text-sm font-medium text-ink-muted">No contacts yet</p>
            <p className="text-xs text-ink-subtle mt-1 mb-4">Add your first contact to get started</p>
            <Link to="/contacts" className="btn-primary text-xs">
              <Plus className="w-3.5 h-3.5" /> Add Contact
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-surface-100">
            {recentContacts.map((c) => {
              const initials = c.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
              return (
                <div key={c.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-surface-50 transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-brand-100 flex items-center justify-center shrink-0">
                    <span className="text-xs font-semibold text-brand-700 font-display">{initials}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-ink">{c.name}</p>
                    <p className="text-xs text-ink-subtle truncate">{c.email}</p>
                  </div>
                  {statusBadge(c.status)}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
        <Link to="/contacts" className="card p-5 hover:shadow-card-hover transition-all duration-200 group flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center group-hover:bg-brand-100 transition-colors">
            <Users className="w-5 h-5 text-brand-600" />
          </div>
          <div>
            <p className="font-medium text-sm text-ink">Manage Contacts</p>
            <p className="text-xs text-ink-muted">Add, edit, or search contacts</p>
          </div>
          <ArrowRight className="w-4 h-4 text-ink-subtle ml-auto group-hover:text-brand-500 group-hover:translate-x-0.5 transition-all" />
        </Link>

        <Link to="/pipeline" className="card p-5 hover:shadow-card-hover transition-all duration-200 group flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center group-hover:bg-purple-100 transition-colors">
            <TrendingUp className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <p className="font-medium text-sm text-ink">Sales Pipeline</p>
            <p className="text-xs text-ink-muted">View and manage your pipeline</p>
          </div>
          <ArrowRight className="w-4 h-4 text-ink-subtle ml-auto group-hover:text-purple-500 group-hover:translate-x-0.5 transition-all" />
        </Link>
      </div>
    </div>
  );
}
