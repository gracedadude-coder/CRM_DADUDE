import React, { useEffect, useState, useCallback } from "react";
import { useContacts } from "../hooks/useContacts";
import ContactModal from "../components/ContactModal";
import { Plus, Search, Pencil, Trash2, Phone, Mail, StickyNote } from "lucide-react";
import toast from "react-hot-toast";

const STATUS_BADGE = {
  lead: "badge-lead",
  contacted: "badge-contacted",
  proposal: "badge-proposal",
  closed: "badge-closed",
  inactive: "badge-inactive",
};

export default function Contacts() {
  const { contacts, loading, fetchContacts, createContact, updateContact, deleteContact } = useContacts();
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(null); // null | { mode: 'add' | 'edit', contact?: object }
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  const handleSearch = useCallback(
    (e) => {
      const q = e.target.value;
      setSearch(q);
      const t = setTimeout(() => fetchContacts(q), 300);
      return () => clearTimeout(t);
    },
    [fetchContacts]
  );

  const handleSave = async (form) => {
    try {
      if (modal.mode === "edit") {
        await updateContact(modal.contact.id, form);
        toast.success("Contact updated");
      } else {
        await createContact(form);
        toast.success("Contact added");
      }
    } catch (err) {
      toast.error(err.message);
      throw err;
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteContact(id);
      toast.success("Contact deleted");
      setDeleteConfirm(null);
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-6 lg:p-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display font-bold text-2xl text-ink">Contacts</h1>
          <p className="text-sm text-ink-muted mt-0.5">{contacts.length} total contacts</p>
        </div>
        <button onClick={() => setModal({ mode: "add" })} className="btn-primary shrink-0">
          <Plus className="w-4 h-4" /> Add Contact
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-subtle" />
        <input
          className="input-field pl-10"
          placeholder="Search by name, email, or phone…"
          value={search}
          onChange={handleSearch}
        />
      </div>

      {/* Table */}
      {loading ? (
        <div className="card overflow-hidden">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center gap-4 px-5 py-4 border-b border-surface-100 animate-pulse">
              <div className="w-9 h-9 bg-surface-200 rounded-xl" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-surface-200 rounded w-40" />
                <div className="h-3 bg-surface-100 rounded w-28" />
              </div>
            </div>
          ))}
        </div>
      ) : contacts.length === 0 ? (
        <div className="card py-16 text-center">
          <div className="w-14 h-14 bg-surface-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Search className="w-7 h-7 text-ink-subtle" />
          </div>
          <p className="text-sm font-medium text-ink-muted">
            {search ? "No contacts match your search" : "No contacts yet"}
          </p>
          {!search && (
            <button onClick={() => setModal({ mode: "add" })} className="btn-primary mt-4 mx-auto">
              <Plus className="w-4 h-4" /> Add your first contact
            </button>
          )}
        </div>
      ) : (
        <div className="card overflow-hidden">
          {/* Desktop table header */}
          <div className="hidden sm:grid grid-cols-[2fr_2fr_1fr_1fr_auto] gap-4 px-5 py-3 bg-surface-50 border-b border-surface-100 text-xs font-medium text-ink-muted uppercase tracking-wide">
            <span>Name</span>
            <span>Contact Info</span>
            <span>Status</span>
            <span>Notes</span>
            <span>Actions</span>
          </div>

          <div className="divide-y divide-surface-100">
            {contacts.map((c) => {
              const initials = c.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
              return (
                <div key={c.id} className="group sm:grid sm:grid-cols-[2fr_2fr_1fr_1fr_auto] gap-4 px-5 py-4 items-center hover:bg-surface-50/60 transition-colors">
                  {/* Name */}
                  <div className="flex items-center gap-3 mb-2 sm:mb-0">
                    <div className="w-9 h-9 rounded-xl bg-brand-100 flex items-center justify-center shrink-0">
                      <span className="text-xs font-semibold text-brand-700 font-display">{initials}</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-ink">{c.name}</p>
                    </div>
                  </div>

                  {/* Contact info */}
                  <div className="space-y-0.5 mb-2 sm:mb-0">
                    {c.email && (
                      <div className="flex items-center gap-1.5 text-xs text-ink-muted">
                        <Mail className="w-3 h-3 text-ink-subtle shrink-0" />
                        <span className="truncate">{c.email}</span>
                      </div>
                    )}
                    {c.phone && (
                      <div className="flex items-center gap-1.5 text-xs text-ink-muted">
                        <Phone className="w-3 h-3 text-ink-subtle shrink-0" />
                        <span>{c.phone}</span>
                      </div>
                    )}
                  </div>

                  {/* Status */}
                  <div className="mb-2 sm:mb-0">
                    <span className={STATUS_BADGE[c.status] || "badge-inactive"}>
                      {c.status}
                    </span>
                  </div>

                  {/* Notes indicator */}
                  <div>
                    {c.notes ? (
                      <span title={c.notes} className="inline-flex items-center gap-1 text-xs text-ink-subtle">
                        <StickyNote className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Has note</span>
                      </span>
                    ) : (
                      <span className="text-xs text-surface-200">—</span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => setModal({ mode: "edit", contact: c })}
                      className="p-1.5 rounded-lg text-ink-muted hover:text-brand-600 hover:bg-brand-50 transition-colors"
                      title="Edit"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirm(c)}
                      className="p-1.5 rounded-lg text-ink-muted hover:text-red-600 hover:bg-red-50 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Contact modal */}
      {modal && (
        <ContactModal
          contact={modal.contact}
          onSave={handleSave}
          onClose={() => setModal(null)}
        />
      )}

      {/* Delete confirm */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink/20 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-float border border-surface-200 p-6 animate-slide-up">
            <h3 className="font-display font-semibold text-base text-ink mb-2">Delete contact?</h3>
            <p className="text-sm text-ink-muted mb-5">
              This will permanently remove <strong>{deleteConfirm.name}</strong> and all their data.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="btn-secondary flex-1 justify-center">Cancel</button>
              <button onClick={() => handleDelete(deleteConfirm.id)} className="btn-danger flex-1 justify-center">Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
