import React, { useEffect, useState, useCallback } from "react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  closestCorners,
} from "@dnd-kit/core";
import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable,
  arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import api from "../lib/api";
import toast from "react-hot-toast";
import { GripVertical, Mail, Phone, Plus, Loader2 } from "lucide-react";

const COLUMNS = [
  { id: "lead", label: "Lead", color: "bg-blue-500", lightBg: "bg-blue-50", badge: "badge-lead" },
  { id: "contacted", label: "Contacted", color: "bg-amber-500", lightBg: "bg-amber-50", badge: "badge-contacted" },
  { id: "proposal", label: "Proposal", color: "bg-purple-500", lightBg: "bg-purple-50", badge: "badge-proposal" },
  { id: "closed", label: "Closed", color: "bg-green-500", lightBg: "bg-green-50", badge: "badge-closed" },
];

function KanbanCard({ contact, isDragging = false }) {
  const initials = contact.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
  return (
    <div className={`bg-white rounded-xl border border-surface-200 p-3.5 shadow-card ${isDragging ? "drag-overlay" : "hover:shadow-card-hover"} transition-all duration-150`}>
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg bg-brand-100 flex items-center justify-center shrink-0 mt-0.5">
          <span className="text-xs font-semibold text-brand-700 font-display">{initials}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-ink leading-snug">{contact.name}</p>
          {contact.email && (
            <div className="flex items-center gap-1 mt-1">
              <Mail className="w-3 h-3 text-ink-subtle shrink-0" />
              <span className="text-xs text-ink-muted truncate">{contact.email}</span>
            </div>
          )}
          {contact.phone && (
            <div className="flex items-center gap-1">
              <Phone className="w-3 h-3 text-ink-subtle shrink-0" />
              <span className="text-xs text-ink-muted">{contact.phone}</span>
            </div>
          )}
          {contact.notes && (
            <p className="text-xs text-ink-subtle mt-1.5 line-clamp-2 leading-relaxed">{contact.notes}</p>
          )}
        </div>
        <GripVertical className="w-4 h-4 text-ink-subtle shrink-0 mt-0.5 cursor-grab active:cursor-grabbing" />
      </div>
    </div>
  );
}

function SortableCard({ contact }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: contact.id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  };
  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
      <KanbanCard contact={contact} />
    </div>
  );
}

function KanbanColumn({ column, contacts }) {
  return (
    <div className="flex flex-col min-w-[260px] w-[260px] lg:w-auto lg:flex-1">
      {/* Column header */}
      <div className="flex items-center gap-2.5 mb-3">
        <div className={`w-2.5 h-2.5 rounded-full ${column.color}`} />
        <span className="font-display font-semibold text-sm text-ink">{column.label}</span>
        <span className="ml-auto text-xs font-medium text-ink-subtle bg-surface-100 px-2 py-0.5 rounded-full">
          {contacts.length}
        </span>
      </div>

      {/* Cards drop zone */}
      <div className={`flex-1 rounded-2xl p-3 space-y-2.5 min-h-[200px] border-2 border-dashed border-surface-200 ${column.lightBg}/40 transition-colors`}>
        <SortableContext items={contacts.map((c) => c.id)} strategy={verticalListSortingStrategy}>
          {contacts.map((c) => (
            <SortableCard key={c.id} contact={c} />
          ))}
        </SortableContext>
        {contacts.length === 0 && (
          <div className="flex items-center justify-center h-24 text-xs text-ink-subtle">
            Drop contacts here
          </div>
        )}
      </div>
    </div>
  );
}

export default function Pipeline() {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeId, setActiveId] = useState(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  );

  const fetchContacts = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/contacts");
      setContacts(data.filter((c) => ["lead", "contacted", "proposal", "closed"].includes(c.status)));
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  const getColumn = (id) => contacts.find((c) => c.id === id)?.status;

  const handleDragStart = ({ active }) => setActiveId(active.id);

  const handleDragOver = ({ active, over }) => {
    if (!over) return;
    const fromCol = getColumn(active.id);
    const toCol = COLUMNS.find((c) => c.id === over.id)?.id ?? getColumn(over.id);
    if (!toCol || fromCol === toCol) return;
    setContacts((prev) =>
      prev.map((c) => (c.id === active.id ? { ...c, status: toCol } : c))
    );
  };

  const handleDragEnd = async ({ active, over }) => {
    setActiveId(null);
    if (!over) return;
    const contact = contacts.find((c) => c.id === active.id);
    if (!contact) return;
    try {
      await api.put(`/contacts/${active.id}`, { status: contact.status });
    } catch (err) {
      toast.error("Failed to update status");
      fetchContacts();
    }
  };

  const activeContact = contacts.find((c) => c.id === activeId);

  return (
    <div className="p-6 lg:p-8 flex flex-col h-full">
      <div className="mb-6">
        <h1 className="font-display font-bold text-2xl text-ink">Pipeline</h1>
        <p className="text-sm text-ink-muted mt-0.5">Drag contacts between columns to update their stage</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center flex-1">
          <div className="flex flex-col items-center gap-3 text-ink-muted">
            <Loader2 className="w-6 h-6 animate-spin text-brand-500" />
            <span className="text-sm">Loading pipeline…</span>
          </div>
        </div>
      ) : (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
        >
          {/* Scrollable kanban board */}
          <div className="flex gap-4 overflow-x-auto pb-4 flex-1">
            {COLUMNS.map((col) => (
              <KanbanColumn
                key={col.id}
                column={col}
                contacts={contacts.filter((c) => c.status === col.id)}
              />
            ))}
          </div>

          <DragOverlay>
            {activeContact ? <KanbanCard contact={activeContact} isDragging /> : null}
          </DragOverlay>
        </DndContext>
      )}

      {/* Tip */}
      {!loading && (
        <p className="text-xs text-ink-subtle mt-4 text-center">
          💡 Update contact statuses from the{" "}
          <a href="/contacts" className="text-brand-500 hover:underline">Contacts</a> page to add more cards
        </p>
      )}
    </div>
  );
}
