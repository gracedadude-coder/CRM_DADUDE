import React, { useState, useEffect } from "react";
import { X } from "lucide-react";

const STATUSES = ["lead", "contacted", "proposal", "closed", "inactive"];

export default function ContactModal({ contact, onSave, onClose }) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    status: "lead",
    notes: "",
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (contact) {
      setForm({
        name: contact.name || "",
        email: contact.email || "",
        phone: contact.phone || "",
        status: contact.status || "lead",
        notes: contact.notes || "",
      });
    }
  }, [contact]);

  const set = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSave(form);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink/20 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-float border border-surface-200 animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-surface-100">
          <h2 className="font-display font-semibold text-base text-ink">
            {contact ? "Edit Contact" : "New Contact"}
          </h2>
          <button onClick={onClose} className="text-ink-subtle hover:text-ink transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="label">Full Name *</label>
            <input className="input-field" placeholder="Jane Smith" value={form.name} onChange={set("name")} required />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Email</label>
              <input className="input-field" type="email" placeholder="jane@co.com" value={form.email} onChange={set("email")} />
            </div>
            <div>
              <label className="label">Phone</label>
              <input className="input-field" placeholder="+1 555 0100" value={form.phone} onChange={set("phone")} />
            </div>
          </div>

          <div>
            <label className="label">Status</label>
            <select className="input-field" value={form.status} onChange={set("status")}>
              {STATUSES.map((s) => (
                <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="label">Notes</label>
            <textarea
              className="input-field resize-none"
              rows={3}
              placeholder="Any additional notes about this contact…"
              value={form.notes}
              onChange={set("notes")}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1 justify-center">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Saving…
                </span>
              ) : contact ? "Save Changes" : "Add Contact"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
