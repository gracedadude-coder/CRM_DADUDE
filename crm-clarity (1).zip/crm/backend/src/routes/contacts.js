const express = require("express");
const router = express.Router();
const supabase = require("../config/supabase");

// GET /api/contacts — list all contacts for the authenticated user
router.get("/", async (req, res) => {
  try {
    const { search, limit } = req.query;

    let query = supabase
      .from("contacts")
      .select("*")
      .eq("user_id", req.userId)
      .order("created_at", { ascending: false });

    if (search) {
      query = query.or(`name.ilike.%${search}%,email.ilike.%${search}%,phone.ilike.%${search}%`);
    }

    if (limit) {
      query = query.limit(parseInt(limit));
    }

    const { data, error } = await query;
    if (error) throw error;
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/contacts/:id
router.get("/:id", async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("contacts")
      .select("*")
      .eq("id", req.params.id)
      .eq("user_id", req.userId)
      .single();

    if (error) throw error;
    if (!data) return res.status(404).json({ error: "Contact not found" });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/contacts
router.post("/", async (req, res) => {
  try {
    const { name, email, phone, status, notes } = req.body;

    if (!name?.trim()) {
      return res.status(400).json({ error: "Name is required" });
    }

    const validStatuses = ["lead", "contacted", "proposal", "closed", "inactive"];
    const contactStatus = validStatuses.includes(status) ? status : "lead";

    const { data, error } = await supabase
      .from("contacts")
      .insert({
        user_id: req.userId,
        name: name.trim(),
        email: email?.trim() || null,
        phone: phone?.trim() || null,
        status: contactStatus,
        notes: notes?.trim() || null,
      })
      .select()
      .single();

    if (error) throw error;
    res.status(201).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/contacts/:id
router.put("/:id", async (req, res) => {
  try {
    const { name, email, phone, status, notes } = req.body;

    // Build update object with only provided fields
    const updates = {};
    if (name !== undefined) updates.name = name.trim();
    if (email !== undefined) updates.email = email?.trim() || null;
    if (phone !== undefined) updates.phone = phone?.trim() || null;
    if (notes !== undefined) updates.notes = notes?.trim() || null;

    if (status !== undefined) {
      const validStatuses = ["lead", "contacted", "proposal", "closed", "inactive"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ error: "Invalid status value" });
      }
      updates.status = status;
    }

    updates.updated_at = new Date().toISOString();

    const { data, error } = await supabase
      .from("contacts")
      .update(updates)
      .eq("id", req.params.id)
      .eq("user_id", req.userId)
      .select()
      .single();

    if (error) throw error;
    if (!data) return res.status(404).json({ error: "Contact not found" });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/contacts/:id
router.delete("/:id", async (req, res) => {
  try {
    const { error } = await supabase
      .from("contacts")
      .delete()
      .eq("id", req.params.id)
      .eq("user_id", req.userId);

    if (error) throw error;
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
