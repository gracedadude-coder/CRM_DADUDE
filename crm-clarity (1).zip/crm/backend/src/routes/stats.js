const express = require("express");
const router = express.Router();
const supabase = require("../config/supabase");

// GET /api/stats — dashboard summary stats
router.get("/", async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("contacts")
      .select("status")
      .eq("user_id", req.userId);

    if (error) throw error;

    const stats = {
      total: data.length,
      leads: data.filter((c) => c.status === "lead").length,
      contacted: data.filter((c) => c.status === "contacted").length,
      proposals: data.filter((c) => c.status === "proposal").length,
      closed: data.filter((c) => c.status === "closed").length,
      inactive: data.filter((c) => c.status === "inactive").length,
    };

    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
